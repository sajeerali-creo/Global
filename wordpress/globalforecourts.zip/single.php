<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */
 
get_header(); ?>

<!-- Banner -->
<section class="inner-banner">
  <div class="conatiner">
  <h3>Product Detail</h3>
  </div>
</section>


<!-- about -->
<section class="service each-padding">
  <div class="container">
    <div class="row">
      <div class="col l16 s12 m4">
        <div class="Product-detal-image">
          <?php the_post_thumbnail('full',array("class"=>"img_fit")); ?>
        </div>
      </div>

      <div class="col l16 s12 m8">
        <div class="Product-detal-descri">
          <h2><?php echo get_the_title(); ?></h2>
          <div id="primary" class="content-area">
            <div id="content" class="site-content" role="main">
         
              <?php /* The loop */ ?>
              <?php while ( have_posts() ) : the_post(); ?>
         
                <?php get_template_part( 'content', get_post_format() ); ?>
               
         
              <?php endwhile; ?>
         
            </div><!-- #content -->
          </div><!-- #primary -->
        </div>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>